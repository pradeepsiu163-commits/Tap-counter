# Tap Counter — Android release project
Application ID: com.pradeep.tapcounter
Version 1.0.0 (versionCode 1)
Compile/target SDK 36

Open this folder in Android Studio, sync Gradle, test on a physical Android device, then generate a signed Android App Bundle (.aab) for Google Play.
